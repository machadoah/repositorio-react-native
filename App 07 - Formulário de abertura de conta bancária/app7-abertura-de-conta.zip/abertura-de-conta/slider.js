import React from 'react';
import {Slider} from '@miblanchard/react-native-slider';
import {AppRegistry, StyleSheet, View, Text} from 'react-native';

export class Slider2 extends React.Component {
    state = {
        value: 0,
    };

    render() {
        return (
            <View style={styles.container}>
                <Slider maximumValue={5000} step={100}
                    value={this.state.value}
                    onValueChange={value => this.setState({value})}
                />
                <Text> R$ {(this.state.value)}</Text>
            </View>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginLeft: 10,
        marginRight: 10,
        alignItems: 'stretch',
        justifyContent: 'center',
    },
});

AppRegistry.registerComponent('Slider', () => Slider);

