import {StyleSheet} from 'react-native';


export const styles = StyleSheet.create({
  input:{
      height: 45,
      borderWidth: 1,
      borderColor: '#aaa',
      margin: 10,
      fontSize: 20,
      padding: 10,
      width:180,
      borderRadius:10,
      color:'#000',
      alignItems:'center',
      justifyContent:'center',
      backgroundColor:"#ddd"
      },
      container1:{
        justifyContent:'center',
        alignItems:'center',
        width:'100%',
        height:'100%',
        backgroundColor:"#333"
      },
      image:{
        height:'15%',
        width:"55%",
        margin:10,
        borderRadius:20,
      },
      title:{
        color:'white',
        fontWeight:'bold',
        fontSize: 20
      },
      botao:{height: 45,
      backgroundColor:"#ddd",
      margin: 10,
      fontSize: 20,
      padding: 10,
      width:180,
      borderRadius:10,
      color:'#FFF',
      alignItems:'center',
      justifyContent:'center'
      }
})