import{Calculador} from './components/calculador/calculador';


export default function App(){
  return(
    <Calculador/>
  )
}