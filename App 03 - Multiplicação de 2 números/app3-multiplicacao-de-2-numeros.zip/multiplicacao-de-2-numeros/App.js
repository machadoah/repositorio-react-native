import {Text,View} from 'react-native'
import {Multiplicador} from './components/Multiplicador/multiplicador'
import{styles} from './styles'





export default function App() {
  return (
    <View style={styles.container}>      
      <Multiplicador/>
    </View>

  );
}


