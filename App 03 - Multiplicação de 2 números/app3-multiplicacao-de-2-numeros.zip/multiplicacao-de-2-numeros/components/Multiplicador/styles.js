import{StyleSheet}from 'react-native'



export const styles = StyleSheet.create({
  input:{
      height: 45,
      borderWidth: 1,
      borderColor: '#aaa',
      margin: 10,
      fontSize: 20,
      padding: 10,
      width:180,
      borderRadius:10,
      color:'#fff',
      alignItems:'center',
      justifyContent:'center'
      },
  container:{
    borderColor:'#444',
    borderWidth: 4,
    borderRadius:20,
    justifyContent:'center',
    alignItems:'center',
    padding: '5%',    
    backgroundColor:'#222'

  },
  title:{
    color:'orange',
    fontWeight:'bold',
    fontSize:20,
    marginBottom:'5%'
  },
  text:{ color:'#fff', fontSize:20, fontWeight:'bold'},
  result:{
      height: 45,
      borderColor: '#fff',
      margin: 10,
      fontSize: 20,
      padding: 10,
      borderRadius:10,
      color:'#fff'
      },
      botao:{ 
      backgroundColor:"#00d",
      height:'10%',
      width:120,
      alignItems:'center',
      justifyContent:'center',
      borderRadius:50,
      margin:10,
      }
  
})