import {View,Text,TextInput,Pressable} from 'react-native'
import{useState} from 'react'
import{styles} from './styles'





export function Multiplicador(){

  let[n1, setN1] = useState('');
  let[n2, setN2] = useState('');
  let[result,setResult]= useState('');

  function pegaNumero1(numero){
    setN1(numero);
  }

  function pegaNumero2(numero){
    setN2(numero);
  }

  function calcular(){
    if(n1 == ''){
      setResult('')
      alert('Informe o primeiro número');      
      }
    else if(n2 == ''){
      setResult('')
      alert('Informe o segundo número');      
      }
    else
    setResult(n1*n2)
  }




  return(
      <View style={styles.container}>
        <Text style={styles.title}>
          Multiplicador de Números
        </Text>
      <TextInput 
          keyboardType='numeric'
          placeholder="Primeiro numero" placeholderTextColor="#FFF"
          style={styles.input} onChangeText={pegaNumero1}
      />
      <Text style={styles.text}>
      X
      </Text>
        <TextInput
          keyboardType='numeric'
          placeholder="Segundo numero" placeholderTextColor="#FFF"
          style={styles.input} onChangeText={pegaNumero2}
        />
      
      <Pressable onPress={calcular} style={styles.botao} >
        <Text style={styles.text} >
        Calcular
        </Text>
      </Pressable>
     

      <Text style={styles.result}>      
           {result}
      </Text>
    </View>
  )
}