import { Text, View, StyleSheet, Image, Pressable} from 'react-native';
import {useState} from 'react';

export default function Charada() {

let[resultado, setResultado] = useState(' ');



function sortear(){
  f = Math.floor(Math.random()*11);
  setResultado(f);
}



  return (
    <View style={styles.container}>
      <Image style={styles.logo} source={require('../assets/Charada.png')} />
      <Text style={{color:'white',margin:10}}>
        Pense em um n° de 0 a 10
      </Text>
      <Text style={{color:'red', }}>
        {resultado}
      </Text>
      <Pressable onPress={sortear} style={{backgroundColor:"#4a4", padding:10, borderRadius:15, margin:20}}>
      <Text>
        Descobrir
      </Text>
      </Pressable>
      
    </View>

  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  logo: {
    height: 260,
    width: 220,
    borderRadius:30,
    margin:30,
  },
   input:{
      height: 45,
      borderWidth: 1,
      borderColor: '#aaa',
      margin: 10,
      fontSize: 20,
      padding: 10,
      width:180,
      borderRadius:10,
      color:'#fff',
      alignItems:'center',
      justifyContent:'center'
      }
});
