import { Text, SafeAreaView, StyleSheet } from 'react-native';

import Charada from './components/Charada';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
        Jogo do N° aleatório
      </Text>      
        <Charada />      
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#000',
    padding: 0,
  },
  paragraph: {
    margin: 4,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#fffad0'
  },
});
