import {StyleSheet} from 'react-native';


const styles = StyleSheet.create({
   botao:{
     width:'35%',
     height:'10%',
     alignSelf:'center',
     justifyContent:'center',
     borderRadius:30,
     margin:10
   },
   red:{
     backgroundColor:"#a00"
   },
   redClick:{
     backgroundColor:"#500"
   },
   green:{
     backgroundColor:'#0a0'
   },
   greenClick:{
     backgroundColor:'#050'
   },
   conteudo:{
    alignSelf:'center',
    fontSize:30,
    color:"#eee"
   },
   title:{
     alignSelf:'center',
     marginBottom:70,
     color:'#eee',
     fontSize:30,
     fontWeight:'bold'
   },
   container:{
     backgroundColor:"black",
     height:"100%",
     justifyContent:"center"
   }
});


export {styles}