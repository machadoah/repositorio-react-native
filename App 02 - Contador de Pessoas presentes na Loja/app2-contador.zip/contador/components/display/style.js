import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  tela:{
    margin:1,
    marginBottom:70,
    padding:'15%',
    paddingBottom:'10%' ,
    paddingTop:'10%' ,
    borderColor:"#eee",
    borderWidth:3,
    borderRadius:20,
    alignSelf:'center',
    justifyContent:'center',
    alignItems:'center'    
  },
  dado:{
    fontSize: 100,
    fontFamily:'Arial',
    color:"#eee"
  }

});

export {styles}