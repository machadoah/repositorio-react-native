import{View, Text} from 'react-native';
import{styles} from './style';

function Display(props){  

  return(
    <View style={styles.tela}>
      <Text style={styles.dado}>
        {props.exibir}
      </Text>
    </View>
  )
}

export{Display};