import {useState} from 'react';
import { View, Text,Pressable } from 'react-native';
import {Display} from './components/display/index';
import {styles} from './styles';

 
function App(){
  let[valor, setValor] = useState(0);
  
  function incremento(){
      setValor(valor+1)
  }
  function decremento(){
      setValor(()=>{return valor == 0 ? 0 : valor-1;})
  }
  function zerar(){
    setValor(0)
  }

  return(
    <View style={styles.container}>      
      <View>
      <Text style={styles.title}>
          Contador de Pessoas
      </Text>      
    <Display exibir={valor}/>
    <Pressable style={({pressed})=>[pressed ? styles.greenClick: styles.green, styles.botao]} onPress={()=> incremento()}>
      <Text style={styles.conteudo}>
      +
      </Text>
    </Pressable>

    <Pressable style={({pressed})=>[ pressed ? styles.redClick : styles.red ,styles.botao]} onPress={()=>decremento()} onLongPress={()=>zerar()}>
      <Text style={styles.conteudo}>
      -
      </Text>
    </Pressable>
    </View>
    </View>
    
  );
}




export default App;
