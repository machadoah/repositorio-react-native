






























import { Text, SafeAreaView, StyleSheet, Image } from 'react-native';

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';

export default function App() {
  return (
    <SafeAreaView style={styles.container}>        


      <Text style={styles.title}>
        Victor Rocha  Santos
      </Text>
      <Image style={styles.fotoPerfil} source={require('./assets/download.jpg')}/>

      
      <Text style={styles.paragraph}>
      Dados pessoais
      </Text>
      <Text style={styles.corpo}>
      Nome: Victor Rocha dos Santos {'\n'}
      Email: santosrochavictor@gmail.com {'\n'}
      Telefone: (xx)xxxxx-xxxx
      </Text>
       <Text style={styles.paragraph}>
      Formação
      </Text>
      <Text style={styles.corpo}>
      Faculdade de Tecnologia de Praia Grande (Fatec) {'\n'}
      Análise e desenvolvimento de sistemas (cursando){'\n\n'}
      Faculdade do Litoral Sul paulista FALS {'\n'}
      Ciências Contábeis· (2017) {'\n'}     
      </Text>
       <Text style={styles.paragraph}>
      Experiência
      </Text>
      <Text style={styles.corpo}>
      BB Tecnologia e Serviços  {'\n'}
      ServiceNow Developer ( MAI/2023 - Atual){'\n\n'}
      Bradesco {'\n'}
      Gerente assistente PJ (SET/2018 - ABR/2022) {'\n\n'} 
      Poupatempo {'\n'}
      Supervisor  (JUN/2018 - SET/2018) {'\n\n'}     
      </Text>
             
      
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 10,
    padding: 8,
    backgroundColor:"#f7f2dc"
  },
  paragraph: {
    fontFamily:'arial',
    margin: 10,
    fontSize: 21,
    fontWeight: 'bold',
    textAlign: 'left',
    paddingLeft:20
  },corpo:{
    fontFamily:'arial',
    fontSize: 14,
    textAlign: 'left',
    paddingLeft:40
  },
  title: {
    fontFamily:'arial',
    paddingLeft:20,
    margin: 0,
    marginTop:50,
    fontSize: 25,
    fontWeight: 'bold',
    textAlign: 'left',
  },
  fotoPerfil:{
    margin:15,
    marginLeft:40,
    borderRadius: 40,
    width: 200,
    height: 200,
  }
});
